## JavaScript Whack-A-Mole! 
This is an old* project inspired by **Wes Bos** Whack-A-Mole game. Really fun game!  
When the Game Start, by clicking on the title, a Mole will "Pop" from a random Hole, with a random duration. Every successful "Whack" will add 1 to the Score. The game ends after 10 seconds have passed.   
### Features    
  - **Epic graphics**.  
  - A **10 seconds** countdown.  
  - Each Mole will "Pop" from a **random** hole.  
  - Each Mole will be "Whackable" with a **random** amount of time.   
  - When the game is over, you can enter a name and it will display a **Scoreboard**.  
  - Scoreboard data will be stored in **Local Storage**.    

This was made with only pure **vanilla JavaScript**.  
  
If you are interested in working together, feel free to contact me! <mitri.dvp@gmail.com>  

*(07/19/2019) *didn't had a Github account back then, this was the last modified date*    